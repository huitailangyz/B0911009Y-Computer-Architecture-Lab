#ifndef __GRUB_LIKE_CMD_INITRD__
#define __GRUB_LIKE_CMD_INITRD__

int initrd_execed(void);
unsigned int get_initrd_start(void);
unsigned int get_initrd_size(void);

#endif
