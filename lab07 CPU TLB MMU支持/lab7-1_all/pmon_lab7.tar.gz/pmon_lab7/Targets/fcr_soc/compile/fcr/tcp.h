#define	NTCP	1
