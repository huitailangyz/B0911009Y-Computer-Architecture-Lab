#define	NCMD_SHELL	1
#define	NCMD_VERS	0
#define	NCMD_HELP	0
#define	NCMD_EVAL	0
