#define	NMOD_USB_UHCI	0
