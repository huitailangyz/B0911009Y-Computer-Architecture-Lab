#define	NNAND	1
