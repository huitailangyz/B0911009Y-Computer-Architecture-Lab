#define	NLOGFILE	0
#define	NRAMFILES	1
