#define	NMOD_USB_KBD	0
#define	NMOD_USB	0
