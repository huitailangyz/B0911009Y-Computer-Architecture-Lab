#define	NCMD_LWDHCP	0
