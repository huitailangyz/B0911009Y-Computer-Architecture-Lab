#define	NGZIP	1
