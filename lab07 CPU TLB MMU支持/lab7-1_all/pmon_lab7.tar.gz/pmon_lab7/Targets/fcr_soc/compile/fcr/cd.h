#define	NCD	0
