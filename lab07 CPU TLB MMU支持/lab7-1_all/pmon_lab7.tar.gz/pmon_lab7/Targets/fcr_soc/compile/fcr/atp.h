#define	NATP	0
