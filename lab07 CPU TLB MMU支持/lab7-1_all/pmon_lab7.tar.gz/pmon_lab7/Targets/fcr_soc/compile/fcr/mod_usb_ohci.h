#define	NMOD_USB_OHCI	0
