#define	NCMD_HIST	1
