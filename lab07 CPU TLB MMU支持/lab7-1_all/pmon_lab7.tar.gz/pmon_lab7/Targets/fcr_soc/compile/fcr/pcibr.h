#define	NPCIBR	1
