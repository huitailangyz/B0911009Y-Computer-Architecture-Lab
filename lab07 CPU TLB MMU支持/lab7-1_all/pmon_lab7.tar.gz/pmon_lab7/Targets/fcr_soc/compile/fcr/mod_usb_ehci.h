#define	NMOD_USB_EHCI	0
