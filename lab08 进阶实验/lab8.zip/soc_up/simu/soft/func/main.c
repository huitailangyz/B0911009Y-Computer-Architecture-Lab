#include "config.h"

void main()
{ 
    SystemInit();
    cmdline(); 
}
