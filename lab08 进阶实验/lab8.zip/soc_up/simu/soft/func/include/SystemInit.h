void Uart0_Init();
void SystemInit();
void PowerDetec();
//void ReLoad();
