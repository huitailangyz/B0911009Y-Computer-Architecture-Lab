
int help(int argc, char argv[][30]);
int m4(int argc, char argv[][30]);
int m1(int argc, char argv[][30]);
int d4(int argc, char argv[][30]);
int d1(int argc, char argv[][30]);
unsigned int str2num(char str[30]);

int cmdline(void);
